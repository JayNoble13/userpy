class User:

    def __init__(self):
        self.first_name = ["Jay", "Bill", "William"]
        self.last_name = ["Noble", "Noble", "Noble"]
        self.email = ["jay.noble@dojo.com", "bill.noble@dojo.com", "will.noble@dojo.com"]
        self.age = [37, 36, 35]
        self.is_rewards_member = True
        self.points = 0
        print(self)
    def is_rewards_member(self):
        def __init__(gold_card_points):
            gold_card_points = 0
    def enroll(self):
        self.enroll += 200
        self.enroll.first_name[1] - 80
    def spend_points(self,amount):
        self.spend_points -= 200
        self.spend_points.first_name[0] - 50
    def display_user_balance(self):
        print(f"User: {self.name}, Balance: {self.points}")


jay = User("Jay Noble")
bill = User("Bill Noble")
will = User("William Noble")



